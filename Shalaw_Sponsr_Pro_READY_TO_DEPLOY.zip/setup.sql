-- Shalaw Sponsr Pro: run this script in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.sponsorship_orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null check (char_length(customer_name) between 2 and 100),
  contact text not null check (char_length(contact) between 3 and 150),
  platform text not null check (platform in ('TikTok','Snapchat','Both')),
  budget numeric(12,2) not null default 0 check (budget >= 0),
  details text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','completed')),
  created_at timestamptz not null default now()
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.sponsorship_orders enable row level security;
alter table public.admin_users enable row level security;

-- An authenticated administrator may read only their own allow-list row.
drop policy if exists "Admins can read their own admin record" on public.admin_users;
create policy "Admins can read their own admin record"
on public.admin_users for select to authenticated
using (user_id = auth.uid());

-- Customers may submit orders but cannot read or change orders.
drop policy if exists "Public can submit sponsorship orders" on public.sponsorship_orders;
create policy "Public can submit sponsorship orders"
on public.sponsorship_orders for insert to anon, authenticated
with check (
  char_length(customer_name) between 2 and 100
  and char_length(contact) between 3 and 150
  and platform in ('TikTok','Snapchat','Both')
  and budget >= 0
);

-- Only a user explicitly listed in admin_users can read and update orders.
drop policy if exists "Admins can read orders" on public.sponsorship_orders;
create policy "Admins can read orders"
on public.sponsorship_orders for select to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "Admins can update orders" on public.sponsorship_orders;
create policy "Admins can update orders"
on public.sponsorship_orders for update to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

-- Only the project owner should add/remove rows in admin_users from the SQL Editor.
-- Never add a public policy that allows anon users to read admin_users or orders.
